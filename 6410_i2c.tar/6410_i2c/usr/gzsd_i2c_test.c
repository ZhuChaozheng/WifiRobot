#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <linux/spi/spidev.h>
#include <linux/types.h>
#include <errno.h>
#include <string.h>
#include <mtd/mtd-abi.h>
#include <mtd/mtd-user.h>

int main(int argc, char **argv)
{
	int fd;
	int i;
	char *test = "I Love LINUX Programming! This is a mtd driver test file!\n";
	char rec_buf[100];
	char eye_cmd[7] = {1, 2, 3, 4, 5, 6, 7};

	if ((fd=open("/dev/gzsd6410_i2c", O_RDWR)) == -1)
	{
		perror("open flash!\n");
		exit(1);
	}

	write(fd, eye_cmd, 7);

//    while (1)

//	{

#if 0	
	if (read(fd, rec_buf, 7) == -1)
	{
		perror("fail to read!\n");
		exit(1);
	}
	printf("\n");
	for (i=0; i<7; i++)
	{
		printf("%d ", rec_buf[i]);
	}
#endif
	sleep(1);
	printf("\n");
//	}

	return 0;
}



