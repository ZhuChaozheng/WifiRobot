#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/jiffies.h>
#include <linux/i2c.h>
#include <linux/mutex.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/miscdevice.h>

#define dbg printk
//#define dbg(...)
struct s3c6410_i2c
{
	struct i2c_client *client;
};

static struct s3c6410_i2c *s3c_i2c;

static ssize_t gzsd64_i2c_read(struct file *file, char __user *buf, size_t size, loff_t * offset)
{
	struct i2c_msg msg[2];
	unsigned char *rec_buf; 
	int ret;
	int i;
	
	dbg("slave address is %d\n", s3c_i2c->client->addr);
	if (size <= 0)
		return -1;
	
	rec_buf = kmalloc(size, GFP_KERNEL);
	if (!rec_buf)
	{
		printk("fail to malloc rec_buf!\n");
		return -1;
	}
	memset(rec_buf, 0, size);

			
	/* ��AT24CXXʱ,Ҫ�Ȱ�Ҫ���Ĵ洢�ռ�ĵ�ַ������ */
	msg[0].addr  = s3c_i2c->client->addr;  /* Ŀ�� */
	msg[0].buf   = rec_buf;              			/* Դ */
	msg[0].len   = size;        			             /* ��ַ=1 byte */
	msg[0].flags = I2C_M_RD;                     /* ��ʾд */

#if 0
	/* Ȼ������������ */
	msg[1].addr  =  s3c_i2c->client->addr;  /* Դ */
	msg[1].buf   = &data;                 /* Ŀ�� */
	msg[1].len   = 1;                     /* ����=1 byte */
	msg[1].flags = I2C_M_RD;                     /* ��ʾ�� */
#endif

	ret = i2c_transfer( s3c_i2c->client->adapter, msg, 1);
	if (ret)
	{
		copy_to_user(buf, rec_buf, size);
	//	return size;
	}	
#ifdef dbg
	for (i=0; i<size; i++)
	{
		dbg("%d ", rec_buf[i]);
	}
#endif

	kfree(rec_buf);
	return size;
	return -EIO;
}

static ssize_t gzsd64_i2c_write(struct file *file, const char __user *buf, size_t size, loff_t *offset)
{
	unsigned char *val;
	struct i2c_msg msg[1];
	int ret;
	int i;

	val = (unsigned char *)kmalloc(size, GFP_KERNEL);
	if (val == NULL)
	{
		return -1;
	}

	copy_from_user(val, buf, size);

	printk("val are:\n");

	for (i=0; i<size; i++)
	{
		dbg("%d ", val[i]);
	}

	/* ���ݴ�����Ҫ��: Դ,Ŀ��,���� */
	msg[0].addr  =  s3c_i2c->client->addr;  /* Ŀ�� */
	msg[0].buf   = val;                   /* Դ */
	msg[0].len   = size;                     /* ��ַ+����=2 byte */
	msg[0].flags = 0;                     /* ��ʾд */

	ret = i2c_transfer( s3c_i2c->client->adapter, msg, 1);
	if (ret == 1)
		return 2;
	else
		return -EIO;
}

static struct file_operations gzsd6410_i2c_fops = {
	.owner = THIS_MODULE,
	.read  = gzsd64_i2c_read,
	.write = gzsd64_i2c_write,
};




static struct miscdevice i2c_misc = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = "gzsd6410_i2c",
	.fops = &gzsd6410_i2c_fops,
};


static int gzsd6410_probe(struct i2c_client *client, const struct i2c_device_id *did)
{
	int retval;
	
	s3c_i2c = kmalloc(sizeof(struct s3c6410_i2c), GFP_KERNEL);
	if (!s3c_i2c)
	{
		printk("fail to allocate s3c_i2c!\n");
	}
	
	dbg("probe gzsd6410 i2c device!\nDevice name is %s\nDevice address is %d\n", did->name, did->driver_data);

	s3c_i2c->client = client;

	retval = misc_register(&i2c_misc);
	if(retval < 0){
		printk(KERN_INFO "I2C: misc_register failed\n");
		}
	
	return 0;
}

static int gzsd6410_remove(struct i2c_client *client)
{
	misc_deregister(&i2c_misc);
	dbg("remove gzsd6410 i2c driver!\n");
	return 0;
}
struct i2c_device_id dev_id[] = {{"gzsd6410_i2c", 0x07},
							 {},
							};


static struct i2c_driver gzsd6410_i2c_driver =
{
	.driver =
	{
			.name	= "gzsd6410_i2c",
	},
	.probe = gzsd6410_probe,
	.remove  = gzsd6410_remove,
	.id_table = dev_id,
};

static int gzsd_i2c_init(void)
{
	i2c_add_driver(&gzsd6410_i2c_driver);
	return 0;
}

static void gzsd_i2c_exit(void)
{
	i2c_del_driver(&gzsd6410_i2c_driver);
}

module_init(gzsd_i2c_init);
module_exit(gzsd_i2c_exit);

MODULE_LICENSE("GPL");

